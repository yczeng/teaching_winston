import pygame
import time

from Trooper import *

gravity = 0.00000000000000000000000000000000000000000002
sprites = []

stormtrooper_image = pygame.image.load("images/stormtrooper.png")
stormtrooper_image = pygame.transform.scale(stormtrooper_image, (10, 10))
empire = Trooper(stormtrooper_image,(100, 100), gravity)

sprites.append(empire)
def run():
    pygame.init() # makes it so I can use pygame mod
    main_surface = pygame.display.set_mode((1200, 1200)) # How large the window is
    main_surface.fill((30, 40, 200)) # remake surface in window
    while True:
        event = pygame.event.poll()
        if event.type == pygame.QUIT:
            break;
        main_surface.fill((30, 40, 200))
        for sprite in sprites:
            sprite.update # updates sprites
        for sprite in sprites:
            sprite.draw(main_surface) # redraws sprites
    pygame.display.flip()
    pygame.quit()

if __name__ == '__main__':
    run()

